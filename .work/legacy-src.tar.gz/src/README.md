# 石溪相机 —— GEC6818 手机式多应用 UI（拍照 / 录像 / 图库 / AI 聊天）

一个跑在 **GEC6818 开发板（S5P6818 + 7 寸 800×480 电容触摸屏）** 上的手机风格应用集合。
直接用 Linux framebuffer + evdev 触摸实现，**不依赖 Qt / LVGL / libjpeg**，整程序静态链接，
交叉编译后只有一个可执行文件，拷到板子上就能跑。

```
桌面（Launcher）
 ├─ 拍照     全屏取景 + 快门 + 白闪动画 + 对焦框 + 左下角图库缩略图
 ├─ 录像     红键开始/停止，实时计时与帧数，边录边写 MJPEG AVI
 ├─ 图库     4×2 网格 + 左右翻页 + 大图查看 + 视频播放 + 删除（二次确认）
 └─ AI 聊天  气泡对话 + 屏幕键盘 + 发送动画（界面演示，回复为本地预设文案）
```

---

## 一、快速开始

```bash
cd src
make                 # 交叉编译到开发板（arm-linux-gnueabi，静态链接）
./run_board.sh start # 编译 + 上传 + 在板子上后台启动
./run_board.sh shot  # 截屏并转成 PNG，看当前界面
./run_board.sh logs  # 查看运行日志
./run_board.sh stop  # 停止
```

板子默认地址 `root@169.254.193.77`（密码 `123456`），程序安装到 `/root/shixi/`。
可用 `BOARD=root@其它IP ./run_board.sh start` 覆盖。

### 换工具链

默认用 Ubuntu 的 `arm-linux-gnueabi-`（已验证可跑）。如果你机器上是粤嵌课程常用的
`arm-linux-gcc 5.4.0`：

```bash
make CROSS=arm-linux-                       # 用 arm-linux-gcc
make CROSS=arm-linux- ARCH_FLAGS="-mcpu=cortex-a9 -mfpu=neon -mfloat-abi=softfp"
```

**必须静态链接**：板子 rootfs 是 2016 年的 glibc 2.23，新工具链的动态链接程序在板上会报
`GLIBC_2.3x not found`；静态链接后是单文件、无依赖，直接跑。

### 板端小工具

```bash
make tools          # 生成 bin/fbshot（截屏）与 bin/touchsim（虚拟触摸屏）
```

### 在开发板终端上直接运行

```sh
cd /root/shixi
./shixi                 # 前台运行，Ctrl+C 退出
```

### 开机自启（可选，会改板子系统配置）

```sh
# 在开发板上执行：把启动命令追加到 /etc/profile
echo 'cd /root/shixi && ./shixi &' >> /etc/profile
# 取消自启：编辑 /etc/profile 删掉这一行
```

---

## 二、界面操作说明

| 界面 | 操作 |
|---|---|
| 桌面 | 轻触图标进入应用；顶部显示时间/信号/电量，底部显示剩余存储 |
| 拍照 | 中间白色圆键拍照；点画面任意处出现对焦框；左下角缩略图进图库；左上角返回 |
| 录像 | 中间红键开始/停止；录制中显示 `● 00:12` 计时、帧数与已写入大小；最长 120 秒自动停止 |
| 图库 | 左右滑动或拖动翻页；顶部标签切换 全部/照片/视频；轻触缩略图看大图 |
| 图库·查看 | 左右滑动或点两侧箭头切换上一张/下一张；轻触画面隐藏/显示工具条；右上角垃圾桶删除（二次确认） |
| 图库·视频 | 中央按钮播放/暂停；底部进度条可点按跳转；左右滑动快退/快进 10% |
| AI 聊天 | 轻触输入框弹出键盘；三行大字与预设话题可直接点；发送后 0.7 秒出现回复 |

触摸屏是电容屏（gslX680），程序启动时用 `EVIOCGABS` 读取坐标范围自动标定到 800×480，
换屏或坐标反向时可用环境变量调整：

```sh
SHIXI_TOUCH_DEV=/dev/input/event0   # 指定触摸设备
SHIXI_TOUCH_SWAP=1                  # XY 交换
SHIXI_TOUCH_INVERT_X=1              # X 反向
SHIXI_TOUCH_INVERT_Y=1              # Y 反向
```

---

## 三、摄像头

程序启动时自动扫描 `/dev/video0..15`，挑选第一个支持视频采集的设备（UVC 摄像头），
优先协商 **MJPEG**（帧可直接存成照片/写入视频），不支持时退回 **YUYV** 并自行转 RGB 与编码 JPEG。

- **没插摄像头也能演示**：自动切换到动态演示画面（渐变天空 + 移动云 + 计时 + 走动的方块），
  四个应用的全部功能（拍照、录像、图库、删除、播放）都能正常使用。
- **支持热插拔**：程序在演示模式下每 2 秒扫一次设备，摄像头插上后进"拍照/录像"界面会自动切换过去，
  不用重启程序（切换时录像中不会切，避免文件尺寸变化）。
- 指定设备：`SHIXI_CAMERA=/dev/video7 ./shixi`
- 强制演示模式：`SHIXI_CAMERA=none ./shixi`
- 参考的课程 demo（`参考/demo2/录像`）用的是 `/dev/video7`，本程序不写死设备号，插上就能用。

---

## 四、文件与存储

```
/root/shixi/
├── shixi                 可执行文件（静态链接，无需任何动态库）
├── photo/IMG_20260921_180318.jpg     照片（JPEG，640×480）
├── video/VID_20260921_180515.avi     视频（MJPEG AVI，可用电脑播放器直接播放）
├── .cache/*.tmb          图库缩略图缓存（首次浏览生成，之后秒开）
└── tmp/                  录像临时文件（异常退出后下次启动自动清理）
```

- 根目录可用 `SHIXI_ROOT=/mnt/udisk/shixi ./shixi` 指到 U 盘等其它位置。
- 照片名与视频名都带时间戳，图库按修改时间倒序排列（最新的在最前）。
- 视频是标准 MJPEG AVI，`ffmpeg` / VLC / 暴风影音 / 板上的 `mplayer` 都能直接播放。

---

## 五、代码结构

```
src/
├── main.c                 程序入口、桌面（Launcher）、应用调度、切换动画、主机模拟器
├── core/
│   ├── gfx.[ch]           图形层：framebuffer 双缓冲（FBIOPAN_DISPLAY）、
│   │                      矩形/圆角/圆/三角形/渐变/缩放贴图（SDF 抗锯齿）
│   ├── font.[ch]          点阵字库渲染（中文 + ASCII，4bit/8bit alpha 图集，zlib 压缩）
│   ├── font_atlas.h       自动生成的字库数据（tools/gen_font.py 生成，勿手改）
│   ├── image.[ch]         图片解码/编码（stb_image）、双线性缩放、缩略图
│   ├── input.[ch]         触摸输入：evdev 解析、坐标标定、点击/滑动/长按识别、调试注入
│   ├── ui.[ch]            控件与矢量图标：状态栏、顶栏、按钮、对话框、Toast、26 个图标
│   ├── media.[ch]         媒体库：扫描、命名、删除、缩略图磁盘缓存、空间统计
│   ├── camera.[ch]        V4L2 采集线程（MJPEG/YUYV）+ 演示信号源 + JPEG 供帧
│   ├── avi.[ch]           MJPEG AVI 封装（边录边写、结束回填索引）与解封装（回放）
│   ├── ai.[ch]            AI 聊天后端：拼 JSON / 传输 / 解析回复（异步线程）
│   ├── v4l2compat.h       兼容内核 3.4 的老 v4l2_buffer ABI（见实现要点第 9 条）
│   └── util.h             时间、缓动、格式化等小工具
├── apps/
│   ├── apps.h             应用接口（enter/leave/frame/event）
│   ├── app_camera.c       拍照
│   ├── app_video.c        录像
│   ├── app_gallery.c      图库（网格 / 查看 / 播放 / 删除）
│   └── app_chat.c         AI 聊天界面（本地预设回复，未接入模型）
├── third_party/           stb_image.h、stb_image_write.h（公共领域，单头文件）
└── tools/
    ├── gen_font.py        扫描源码里的文字 -> 生成字库头文件
    ├── icontest.c         主机端把图标排成一张图，方便调美术
    ├── touchsim.c         板端：用 /dev/uinput 造虚拟触摸屏，自动点击测试
    ├── fbshot.c           板端：抓取当前可见画面（考虑双缓冲 yoffset）
    ├── fb2png.py          主机端：把 fbshot 的原始数据转 PNG
    └── SimHei.ttf         字库字体（生成字库用，不参与编译）
```

### 修改界面文字后要重新生成字库

字库只包含源码中真正用到的汉字，改了 UI 文案后执行：

```bash
make font      # 等价于 python3 tools/gen_font.py
make           # 再编译
```

脚本会扫描 `core/`、`apps/` 下所有 `.c/.h` 里的字符串（自动跳过注释），
把用到的字按 4 个字号（15/19/26/44px）渲染成抗锯齿位图，zlib 压缩后写进
`core/font_atlas.h`。字符集里还预留了一批常用字（见脚本里的 `EXTRA`）。

---

## 六、调试与验证工具

### 0) 摄像头诊断（插上摄像头后先跑这个）

```sh
./camtest                # 列出所有 /dev/videoN 的能力、支持格式与分辨率
./camtest /dev/video7    # 对指定设备做采集测试，打印实际帧率并存一帧到 /tmp/cam_frame.jpg
```

若扫不到设备，按提示检查：① 插在 USB Host 口（不是 OTG 口）；② 板子用 5V 电源适配器供电
（摄像头瞬时电流大，供电不足会 `dmesg` 报 `error -32 / unable to enumerate`）；
③ 换短一点的 USB 线，避开延长线；④ 在电脑上确认摄像头是 UVC 免驱的。

### 1) 主机模拟器（不用板子就能调 UI）

把同一份代码编译成主机程序，用脚本驱动点击并输出 PNG：

```bash
make host
cat > /tmp/sim.txt <<'EOF'
frames 10
seed 9 2                 # 生成 9 张示例照片 + 2 段示例视频（用演示画面）
shot /tmp/shots/01_home.png
tap 154 232              # 点“拍照”
frames 40
shot /tmp/shots/02_camera.png
tap 400 400              # 按快门
frames 30
shot /tmp/shots/03_shot.png
quit
EOF
SHIXI_ROOT=/tmp/simroot SHIXI_SIM_SCRIPT=/tmp/sim.txt SHIXI_CAMERA=none ./bin/shixi_host
```

脚本命令：`tap X Y`、`swipe X0 Y0 X1 Y1`、`down/up/long X Y`、`frames N`、`wait MS`、
`shot PATH`、`seed NP NV`、`quit`。

### 1b) 用 LD_PRELOAD 假摄像头测真实 V4L2 代码路径（主机上）

板子暂时没摄像头时，可以在主机上伪造一个 UVC 摄像头，把 `camera.c` 的
V4L2 流程（能力查询 → 格式协商 → mmap 缓冲 → DQBUF/QBUF → MJPEG 解码）
完整跑一遍：

```bash
make host
gcc -O2 -fPIC -shared -o bin/v4l2mock.so tools/v4l2mock.c -ldl
mkdir -p /tmp/mockframes && cp some/*.jpg /tmp/mockframes/     # 循环播放的 MJPEG 帧
MOCK_VIDEO_DIR=/tmp/mockframes MOCK_VIDEO_FPS=12 \
  LD_PRELOAD=./bin/v4l2mock.so SHIXI_SIM_SCRIPT=/tmp/sim.txt ./bin/shixi_host
# 可选：MOCK_VIDEO_FORCE_YUYV=1 模拟只支持 YUYV 的摄像头
#       MOCK_VIDEO_DELAY=6     模拟 6 秒后才插上（验证热插拔切换）
```

用这个方式验证过：MJPEG 与 YUYV 两条路径下的预览、拍照（640×480 JPEG）、
录像（AVI 用 ffmpeg 校验通过，帧率按实测写入）。

### 2) 板端无人值守测试

```sh
# 启动时打开调试通道，之后可以从别的终端注入触摸事件
SHIXI_DEBUG_INPUT=1 ./shixi &
echo 'tap 400 400' > /tmp/shixi_ctrl        # 模拟点击
echo 'swipe 700 240 100 240' > /tmp/shixi_ctrl  # 模拟滑动
```

### 3) 验证真实 evdev 输入链路（用 uinput 造虚拟触摸屏）

```sh
./touchsim serve &                          # 会打印命令管道 /tmp/touchsim.fifo
for i in 0 1 2 3 4 5; do echo "event$i: $(cat /sys/class/input/event$i/device/name)"; done
# 找到 shixi-touchsim 对应的 eventN，然后：
SHIXI_TOUCH_DEV=/dev/input/event5 ./shixi &
echo 'tap 154 232' > /tmp/touchsim.fifo     # 真的走一遍 evdev 解析与坐标标定
```

### 4) 截屏

```sh
/tmp/fbshot /tmp/shot.raw     # 板端抓图（自动处理双缓冲 yoffset）
python3 tools/fb2png.py /tmp/shot.raw   # 主机端转 PNG
```

---

## 七、实现要点（可能对报告/答辩有用）

1. **显示**：`/dev/fb0` 是 800×1440 的虚拟缓冲（3 屏），用 `FBIOPAN_DISPLAY` 做双缓冲翻页，
   画面无撕裂；像素格式 `0x00RRGGBB`。
2. **字体**：自研点阵渲染。SimHei 渲染成 4bit alpha 图集 + zlib 压缩（`stb_image` 自带 inflate），
   运行时解压到内存，逐像素 alpha 混合，支持 UTF-8、截断省略、裁剪区。
3. **抗锯齿**：圆角矩形/圆用 SDF 覆盖率，三角形用 3×3 超采样，图标离屏缓存一次后直接贴图。
4. **透明贴图**：离屏画布用 `0xFF000000` 作为"未绘制"键值，贴图时跳过，实现图标透明背景。
5. **输入**：常开 evdev fd + `poll` 非阻塞读，状态机识别 点击/长按/四方向滑动/拖动，
   坐标由 `EVIOCGABS` 动态标定。
6. **摄像头**：`VIDIOC_S_FMT` 先试 MJPEG 再试 YUYV；采集线程负责解码/转码，
   界面线程只做缩放贴图；缓冲区处理完才 `QBUF`，避免被驱动覆盖。
7. **视频封装**：自己实现最小 MJPEG AVI（RIFF/avih/strh/strf/movi/idx1），
   边录边写，结束时回填头部与索引；帧率按**实测**写入，播放速度才正确。
8. **图库性能**：缩略图解码后落盘缓存（186×140，带 mtime+size 校验），二次进入秒开；
   内存里再缓存最近 24 张。
9. **踩过的坑：`struct v4l2_buffer` 的 ABI 不匹配（很关键）**
   板子内核 3.4 里 `struct v4l2_buffer` 是 **68 字节**（时间戳是 32 位 timeval，8 字节），
   而新工具链的内核头文件里时间戳变成 16 字节、结构体是 **80 字节**。
   `VIDIOC_QUERYBUF/QBUF/DQBUF` 的 ioctl 号用 `_IOWR` 把结构体大小编进了命令码
   （`0xc0445609` → `0xc0505609`），老内核认不出 → 直接返回 `ENOTTY`。
   现象很迷惑人：能力查询、格式协商（S_FMT）都正常，一到申请缓冲区就失败，
   换个摄像头也没用。解决见 `core/v4l2compat.h`：显式定义 3.4 的布局，
   并在打开设备时用 `QUERYBUF` 探测该用哪套 ABI（新老内核都能跑）。
   ⚠️ 用 `LD_PRELOAD` 假摄像头测不出这个问题——同进程里结构体当然是一致的，
   所以必须上真机验证。

10. **不用任何第三方 GUI/图像运行时**：只有 stb 两个单头文件，静态链接后单文件部署，
   避免板子 glibc 2.23 与新工具链 glibc 2.39 的版本冲突（这正是必须静态链接的原因）。

---

## 八、AI 聊天（已接入云端大模型）

界面上点"AI聊天"即可和真实模型对话（默认 `deepseek/deepseek-v4.1-flash`）。
回复是**异步请求**，等待时显示"思考中…"+ 三个跳动的点，不会卡界面。

### 怎么用

1. **电脑上开一个终端跑桥接脚本**（保持不关）：
   ```bash
   cd src && ./tools/ai_bridge.sh
   ```
2. 板子上打开程序，进"AI聊天"。因为屏幕键盘只能输 ASCII，中文提问请点下方的
   **快捷提问**（"你会拍照吗？""讲个笑话"…），也可以先用英文/pinyin 聊。
3. 板端自检（不开界面就能验证整条链路）：
   ```bash
   /root/shixi/aitest "你好，介绍一下你自己"
   ```

### 为什么需要桥接脚本

开发板只有一条 169.254.x.x 的链路本地地址、没有默认路由，**自身没有外网**；
反过来电脑也无法主动连到板子（Windows 防火墙挡了入站），
SSH 反向端口转发在这块板子的 sshd 上又被拒（内核 3.4 + OpenSSH 9.9 的组合）。

所以采用**只用已通方向**的方案：

```
板子（写 /root/shixi/tmp/ai_req.json）
      ↓  （电脑 SSH 进板子取走请求——这个方向一直是通的）
电脑：curl -> https://api.commandcode.ai/...（TLS 在电脑上做）
      ↓  （把响应写回 /root/shixi/tmp/ai_resp.txt）
板子：解析 choices[0].message.content 并显示
```

好处：板子端不需要 TLS、不需要存 API key（key 只留在电脑上的 ai.conf），
也不用改任何防火墙/路由设置。

### 配置 `/root/shixi/ai.conf`

```ini
mode=bridge        # bridge=走电脑中转（默认）；direct=板子上外网时用 openssl 直连
api_host=api.commandcode.ai
api_path=/provider/v1/chat/completions
api_key=user_...   # direct 模式需要；bridge 模式板子上可留空
api_model=deepseek/deepseek-v4.1-flash
max_tokens=800     # 这是推理模型，太小会把 token 花在思考上导致 content 为空
reasoning_effort=low
# transport=...    # 可选：自定义传输命令，$REQ 会被替换成请求文件路径
```

### 实现要点

- `core/ai.c`：请求在独立线程里通过 `popen()` 执行"传输命令"完成；
  请求 JSON 自己拼（严格转义），响应只取 `choices[0].message.content`
  （**推理模型还会返回 `reasoning` 字段，界面不显示**），出错则取 `error.message`。
- 传输命令由配置决定：bridge 模式是"写请求文件→等响应文件"，
  direct 模式是 `openssl s_client -quiet -connect <host>:443 -servername <host>`。
- 字库为此扩到了 **GB2312 常用汉字全集（7445 字形）**——模型回复是任意汉字，
  只收源码里出现的字会显示成空白；emoji 等字库外字符在 `strip_unsupported()` 里剔除。
- 聊天上下文取最近 12 条消息一起发给模型。

### 注意

- 用 AI 聊天时必须**连着电脑并开着 ai_bridge.sh**；桥接没开时发消息会在约 12 秒后
  提示"没有收到回复（…请确认电脑上 ai_bridge.sh 正在运行）"。
- `ai.conf` 里有 API key，不要提交到公开仓库；担心泄露可以在控制台轮换 key。
- 推理模型响应较慢（2~5 秒），比普通模型更"话痨"，`max_tokens` 别再调小于 400。

## 九、音频说明（重要）

- **本项目的摄像头不带 USB 音频**：这类便宜 UVC 模块通常只有视频接口
  （`class 0x0e`），没有音频接口（`class 0x01`），所以 Linux 下看不到它的麦克风。
- **板子内核没有 USB 音频驱动**：`/lib/modules/*/modules.builtin` 里没有
  `snd-usb-audio`，板上也没有任何可加载模块 → 插 USB 麦克风/声卡也用不了。
- **板子自带音频输入可用**（红色 3.5mm 口，ALC5623 codec，节点 `/dev/snd/pcmC0D0c`），
  但板上没有录音工具（`ffmpeg` 只编译了 ALSA 输出，没有输入；没有 `arecord`）。
  要录音需要自己写一个小 ALSA 采集程序（直接 ioctl，不依赖 libasound）。
- 因此当前**录像没有声音**。

## 十、已知限制

- AI 聊天已接入真实模型（见第八节），但**必须连着电脑并开着 `tools/ai_bridge.sh`**
  （板子自身没有外网）；屏幕键盘只能输 ASCII，中文提问请用快捷话题。
- 录像**没有声音**，原因见第八节。
- 视频帧率取决于摄像头：MJPEG 摄像头可到 15–30fps；YUYV 摄像头需要板上编码 JPEG，
  实测约 6–10fps（录制时按实测帧率写头，播放速度正常）。
- 演示画面模式下 JPEG 编码占用较高，预览约 17fps；接真实摄像头会更流畅。
- 板子没有联网对时，时间来自 RTC；`./run_board.sh` 里可用 `date -s` 手动校准。
- 板载存储只有约 240MB 可用，录像最长限制 120 秒，空间不足会自动停止并保存。
