/*
 * font.h — 点阵字库渲染（中文 + ASCII）
 *
 * 字形数据在 core/font_atlas.h 中由 tools/gen_font.py 生成：
 * 4 个字号，每号一张 8bit alpha 图集（zlib 压缩），运行时解压到内存。
 */
#ifndef SHIXI_FONT_H
#define SHIXI_FONT_H

#include "gfx.h"

typedef enum {
    FONT_SMALL = 0,   /* 15px：状态栏、说明文字 */
    FONT_BODY  = 1,   /* 19px：正文、按钮 */
    FONT_TITLE = 2,   /* 24px：标题 */
    FONT_HUGE  = 3,   /* 42px：时钟、大号数字 */
    FONT_COUNT
} FontId;

int font_init(void);                                  /* 解压字库，返回 0 成功 */
int font_height(FontId f);                            /* 行高 */
int font_ascent(FontId f);                            /* 基线到行顶距离 */

int text_width(FontId f, const char *utf8);           /* 单行宽度(像素) */
int text_draw(Surface *s, int x, int y, const char *utf8, FontId f, uint32_t color);
int text_draw_a(Surface *s, int x, int y, const char *utf8, FontId f, uint32_t color, int alpha);
/* y 为行顶；返回绘制后光标 x */
int text_draw_center(Surface *s, int cx, int y, const char *utf8, FontId f, uint32_t color);
int text_draw_right(Surface *s, int rx, int y, const char *utf8, FontId f, uint32_t color);
/* 超出 max_w 时截断并追加省略号 */
int text_draw_ellipsis(Surface *s, int x, int y, const char *utf8, FontId f, uint32_t color, int max_w);
/* 垂直居中于 [y, y+h] */
int text_draw_vcenter(Surface *s, int x, int y, int h, const char *utf8, FontId f, uint32_t color);
int text_draw_vcenter_center(Surface *s, int cx, int y, int h, const char *utf8, FontId f, uint32_t color);

#endif /* SHIXI_FONT_H */
