/*
 * font.c — 点阵字库渲染实现
 */
#include "font.h"
#include "font_atlas.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* stb_image 自带的 zlib 解压（实现位于 third_party/stb_impl.c） */
extern char *stbi_zlib_decode_malloc(const char *buffer, int len, int *outlen);

static unsigned char *atlas_px[FONT_COUNT];
static int atlas_ready = 0;

/* ---------- UTF-8 ---------- */
static uint32_t utf8_next(const char **pp)
{
    const unsigned char *p = (const unsigned char *)*pp;
    uint32_t c = *p;
    if (c < 0x80) {
        *pp = (const char *)(p + 1);
        return c;
    } else if ((c & 0xE0) == 0xC0) {
        if (!p[1]) { *pp = (const char *)(p + 1); return c; }
        c = ((c & 0x1F) << 6) | (p[1] & 0x3F);
        *pp = (const char *)(p + 2);
        return c;
    } else if ((c & 0xF0) == 0xE0) {
        if (!p[1] || !p[2]) { *pp = (const char *)(p + 1); return c; }
        c = ((c & 0x0F) << 12) | ((p[1] & 0x3F) << 6) | (p[2] & 0x3F);
        *pp = (const char *)(p + 3);
        return c;
    } else if ((c & 0xF8) == 0xF0) {
        if (!p[1] || !p[2] || !p[3]) { *pp = (const char *)(p + 1); return c; }
        c = ((c & 0x07) << 18) | ((p[1] & 0x3F) << 12) | ((p[2] & 0x3F) << 6) | (p[3] & 0x3F);
        *pp = (const char *)(p + 4);
        return c;
    }
    *pp = (const char *)(p + 1);
    return c;
}

int font_init(void)
{
    if (atlas_ready) return 0;
    for (int i = 0; i < FONT_ATLAS_COUNT; i++) {
        const FontAtlas *a = &g_font_atlases[i];
        int outlen = 0;
        char *raw = stbi_zlib_decode_malloc((const char *)a->bits_z, a->bits_z_len, &outlen);
        if (!raw) {
            fprintf(stderr, "font: 解压字库 %s 失败\n", a->name);
            return -1;
        }
        int need = (a->bpp == 4)
                 ? (a->atlas_w * a->atlas_h + 1) / 2
                 : (a->atlas_w * a->atlas_h);
        if (outlen < need) {
            fprintf(stderr, "font: 字库 %s 数据不完整 (%d < %d)\n", a->name, outlen, need);
            free(raw);
            return -1;
        }
        atlas_px[i] = (unsigned char *)raw;
    }
    atlas_ready = 1;
    return 0;
}

int font_height(FontId f)
{
    if (f < 0 || f >= FONT_ATLAS_COUNT) f = FONT_BODY;
    return g_font_atlases[f].ascent + g_font_atlases[f].descent;
}

int font_ascent(FontId f)
{
    if (f < 0 || f >= FONT_ATLAS_COUNT) f = FONT_BODY;
    return g_font_atlases[f].ascent;
}

static const FontGlyph *glyph_find(const FontAtlas *a, uint32_t cp)
{
    int lo = 0, hi = a->glyph_count - 1;
    while (lo <= hi) {
        int mid = (lo + hi) >> 1;
        if (a->glyphs[mid].cp == cp) return &a->glyphs[mid];
        if (a->glyphs[mid].cp < cp) lo = mid + 1; else hi = mid - 1;
    }
    return NULL;
}

static int glyph_advance(FontId f, uint32_t cp)
{
    const FontAtlas *a = &g_font_atlases[f];
    const FontGlyph *g = glyph_find(a, cp);
    if (g) return g->adv;
    /* 未收录：用一个空格宽度占位 */
    return a->px / 3;
}

int text_width(FontId f, const char *utf8)
{
    if (!utf8) return 0;
    if (f < 0 || f >= FONT_ATLAS_COUNT) f = FONT_BODY;
    if (!atlas_ready && font_init() != 0) return 0;
    int w = 0;
    const char *p = utf8;
    while (*p) {
        uint32_t cp = utf8_next(&p);
        if (cp == '\n') break;
        w += glyph_advance(f, cp);
    }
    return w;
}

int text_draw_a(Surface *s, int x, int y, const char *utf8, FontId f, uint32_t color, int alpha)
{
    if (!s || !utf8 || alpha <= 0) return x;
    if (f < 0 || f >= FONT_ATLAS_COUNT) f = FONT_BODY;
    if (!atlas_ready && font_init() != 0) return x;

    const FontAtlas *a = &g_font_atlases[f];
    const unsigned char *px = atlas_px[f];
    const int bpp = a->bpp;
    int baseline = y + a->ascent;
    int cx = x;
    /* 裁剪区：文字也必须遵守，否则会画到别的区域上 */
    int cx0, cy0, cx1, cy1;
    gfx_clip_rect(&cx0, &cy0, &cx1, &cy1);
    const char *p = utf8;

    int cr = (color >> 16) & 0xFF, cg = (color >> 8) & 0xFF, cb = color & 0xFF;

    while (*p) {
        uint32_t cp = utf8_next(&p);
        if (cp == '\n') break;
        if (cp == '\r') continue;
        const FontGlyph *g = glyph_find(a, cp);
        if (!g) { cx += a->px / 3; continue; }
        if (g->w && g->h) {
            int gx = cx + g->bx;
            int gy = baseline + g->by;
            for (int j = 0; j < g->h; j++) {
                int dy = gy + j;
                if (dy < 0 || dy >= s->h || dy < cy0 || dy >= cy1) continue;
                const unsigned char *srow = px + (size_t)(g->gy + j) * a->atlas_w + g->gx;
                uint32_t *drow = s->px + (size_t)dy * s->stride;
                for (int i = 0; i < g->w; i++) {
                    int dx = gx + i;
                    if (dx < 0 || dx >= s->w || dx < cx0 || dx >= cx1) continue;
                    int cov;
                    if (bpp == 4) {
                        size_t idx = (size_t)(g->gy + j) * a->atlas_w + g->gx + i;
                        unsigned char b = px[idx >> 1];
                        cov = (idx & 1) ? (b & 0x0F) : (b >> 4);
                        cov = cov * 17;   /* 4bit -> 8bit */
                    } else {
                        cov = srow[i];
                    }
                    if (!cov) continue;
                    int aa = cov * alpha / 255;
                    if (aa <= 0) continue;
                    uint32_t d = drow[dx];
                    if (aa >= 255) { drow[dx] = color; continue; }
                    /* 用字形覆盖率混合指定颜色 */
                    uint32_t ia = 255 - aa;
                    uint32_t dr = (d >> 16) & 0xFF, dg = (d >> 8) & 0xFF, db = d & 0xFF;
                    uint32_t t, r, gg, b;
                    t = cr * aa + dr * ia + 128; r = (t + (t >> 8)) >> 8;
                    t = cg * aa + dg * ia + 128; gg = (t + (t >> 8)) >> 8;
                    t = cb * aa + db * ia + 128; b = (t + (t >> 8)) >> 8;
                    drow[dx] = (r << 16) | (gg << 8) | b;
                }
            }
        }
        cx += g->adv;
    }
    return cx;
}

int text_draw(Surface *s, int x, int y, const char *utf8, FontId f, uint32_t color)
{
    return text_draw_a(s, x, y, utf8, f, color, 255);
}

int text_draw_center(Surface *s, int cx, int y, const char *utf8, FontId f, uint32_t color)
{
    int w = text_width(f, utf8);
    return text_draw(s, cx - w / 2, y, utf8, f, color);
}

int text_draw_right(Surface *s, int rx, int y, const char *utf8, FontId f, uint32_t color)
{
    int w = text_width(f, utf8);
    return text_draw(s, rx - w, y, utf8, f, color);
}

int text_draw_vcenter(Surface *s, int x, int y, int h, const char *utf8, FontId f, uint32_t color)
{
    int fh = font_height(f);
    return text_draw(s, x, y + (h - fh) / 2, utf8, f, color);
}

int text_draw_vcenter_center(Surface *s, int cx, int y, int h, const char *utf8, FontId f, uint32_t color)
{
    int w = text_width(f, utf8);
    int fh = font_height(f);
    return text_draw(s, cx - w / 2, y + (h - fh) / 2, utf8, f, color);
}

int text_draw_ellipsis(Surface *s, int x, int y, const char *utf8, FontId f, uint32_t color, int max_w)
{
    if (!utf8) return x;
    if (text_width(f, utf8) <= max_w) return text_draw(s, x, y, utf8, f, color);
    int dots = text_width(f, "...");
    int budget = max_w - dots;
    if (budget < 0) budget = 0;

    /* 逐字累加，超出预算即停 */
    char buf[256];
    int bi = 0, w = 0;
    const char *p = utf8;
    while (*p) {
        const char *start = p;
        uint32_t cp = utf8_next(&p);
        if (cp == '\n') break;
        int adv = glyph_advance(f, cp);
        if (w + adv > budget) break;
        int len = (int)(p - start);
        if (bi + len + 4 >= (int)sizeof(buf)) break;
        memcpy(buf + bi, start, len);
        bi += len;
        w += adv;
    }
    buf[bi] = 0;
    strcat(buf, "...");
    return text_draw(s, x, y, buf, f, color);
}
