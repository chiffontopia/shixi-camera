/*
 * ai.c — AI 聊天后端实现
 *
 * 关键点：
 *  1. 请求 JSON 自己拼，注意转义（引号/反斜杠/换行/控制字符），UTF-8 原样透传；
 *  2. 响应只取 choices[0].message.content（这是推理模型，reasoning 字段不显示），
 *     出错时取 error.message；
 *  3. 网络动作在独立线程里跑（popen 一个 shell 命令），界面线程只轮询状态；
 *  4. 传输方式可配置：默认 bridge（靠电脑上的 ai_bridge.sh 中转），
 *     也可 direct（板子自己能上外网时用 openssl s_client 直连）。
 */
#include "ai.h"
#include "util.h"
#include "media.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <ctype.h>

/* ---------------- 配置 ---------------- */
typedef struct {
    char mode[16];        /* bridge / direct */
    char host[128];
    char path[128];
    char key[256];
    char model[96];
    int  max_tokens;
    char reasoning_effort[16];
    char transport[512];  /* 自定义传输命令模板（$REQ 会被替换成请求文件路径） */
    char req_file[320];   /* bridge 模式：请求文件 */
    char resp_file[320];  /* bridge 模式：响应文件 */
} AiConfig;

static AiConfig cfg;
static int  cfg_ok = 0;

static void trim(char *s)
{
    int n = (int)strlen(s);
    while (n > 0 && (s[n-1] == '\n' || s[n-1] == '\r' || s[n-1] == ' ' || s[n-1] == '\t')) s[--n] = 0;
    int i = 0;
    while (s[i] == ' ' || s[i] == '\t') i++;
    if (i) memmove(s, s + i, strlen(s + i) + 1);
}

int ai_init(void)
{
    snprintf(cfg.mode, sizeof(cfg.mode), "bridge");
    snprintf(cfg.host, sizeof(cfg.host), "api.commandcode.ai");
    snprintf(cfg.path, sizeof(cfg.path), "/provider/v1/chat/completions");
    cfg.key[0] = 0;
    snprintf(cfg.model, sizeof(cfg.model), "deepseek/deepseek-v4.1-flash");
    cfg.max_tokens = 800;
    snprintf(cfg.reasoning_effort, sizeof(cfg.reasoning_effort), "low");
    cfg.transport[0] = 0;
    snprintf(cfg.req_file, sizeof(cfg.req_file), "%s/ai_req.json", media_tmp_dir());
    snprintf(cfg.resp_file, sizeof(cfg.resp_file), "%s/ai_resp.txt", media_tmp_dir());

    char path[320];
    snprintf(path, sizeof(path), "%s/ai.conf", media_root());
    FILE *f = fopen(path, "r");
    if (f) {
        char line[600];
        while (fgets(line, sizeof(line), f)) {
            char *eq = strchr(line, '=');
            if (!eq) continue;
            *eq = 0;
            char *k = line, *v = eq + 1;
            trim(k); trim(v);
            if (!strcmp(k, "mode")) snprintf(cfg.mode, sizeof(cfg.mode), "%s", v);
            else if (!strcmp(k, "api_host")) snprintf(cfg.host, sizeof(cfg.host), "%s", v);
            else if (!strcmp(k, "api_path")) snprintf(cfg.path, sizeof(cfg.path), "%s", v);
            else if (!strcmp(k, "api_key")) snprintf(cfg.key, sizeof(cfg.key), "%s", v);
            else if (!strcmp(k, "api_model")) snprintf(cfg.model, sizeof(cfg.model), "%s", v);
            else if (!strcmp(k, "max_tokens")) cfg.max_tokens = atoi(v);
            else if (!strcmp(k, "reasoning_effort")) snprintf(cfg.reasoning_effort, sizeof(cfg.reasoning_effort), "%s", v);
            else if (!strcmp(k, "transport")) snprintf(cfg.transport, sizeof(cfg.transport), "%s", v);
            else if (!strcmp(k, "req_file")) snprintf(cfg.req_file, sizeof(cfg.req_file), "%s", v);
            else if (!strcmp(k, "resp_file")) snprintf(cfg.resp_file, sizeof(cfg.resp_file), "%s", v);
        }
        fclose(f);
    }
    if (cfg.max_tokens < 64) cfg.max_tokens = 800;

    /* 环境变量可覆盖（方便临时切直连） */
    const char *e;
    if ((e = getenv("SHIXI_AI_KEY"))) snprintf(cfg.key, sizeof(cfg.key), "%s", e);
    if ((e = getenv("SHIXI_AI_MODE"))) snprintf(cfg.mode, sizeof(cfg.mode), "%s", e);
    if ((e = getenv("SHIXI_AI_MODEL"))) snprintf(cfg.model, sizeof(cfg.model), "%s", e);

    /* direct 模式必须有 key；bridge 模式不需要板子上存 key */
    cfg_ok = strcmp(cfg.mode, "direct") ? 1 : (cfg.key[0] != 0);
    fprintf(stderr, "ai: 模式=%s 模型=%s%s%s\n", cfg.mode, cfg.model,
            cfg_ok ? "" : "（缺少 api_key，未启用）", cfg.transport[0] ? " 使用自定义 transport" : "");
    return cfg_ok ? 0 : -1;
}

int ai_configured(void) { return cfg_ok; }
const char *ai_model(void) { return cfg.model; }
const char *ai_mode(void) { return cfg.mode; }
void ai_shutdown(void) { }

/* ---------------- JSON 工具 ---------------- */
/* 把字符串按 JSON 规则转义写入 out */
static int json_escape(const char *in, char *out, int cap)
{
    int o = 0;
    for (const unsigned char *p = (const unsigned char *)in; *p; p++) {
        unsigned char c = *p;
        const char *rep = NULL;
        char tmp[8];
        switch (c) {
        case '"':  rep = "\\\""; break;
        case '\\': rep = "\\\\"; break;
        case '\n': rep = "\\n"; break;
        case '\r': rep = "\\r"; break;
        case '\t': rep = "\\t"; break;
        case '\b': rep = "\\b"; break;
        case '\f': rep = "\\f"; break;
        default:
            if (c < 0x20) { snprintf(tmp, sizeof(tmp), "\\u%04x", c); rep = tmp; }
            break;
        }
        if (rep) {
            int l = (int)strlen(rep);
            if (o + l >= cap - 1) break;
            memcpy(out + o, rep, l);
            o += l;
        } else {
            if (o >= cap - 1) break;
            out[o++] = (char)c;
        }
    }
    out[o] = 0;
    return o;
}

/* 从 JSON 字符串字面量中解出明文（处理 \" \\ \n \uXXXX） */
static int json_unescape(const char *s, int len, char *out, int cap)
{
    int o = 0;
    for (int i = 0; i < len && o < cap - 1; i++) {
        char c = s[i];
        if (c != '\\') { out[o++] = c; continue; }
        if (i + 1 >= len) break;
        char e = s[++i];
        switch (e) {
        case 'n': out[o++] = '\n'; break;
        case 't': out[o++] = '\t'; break;
        case 'r': out[o++] = '\r'; break;
        case 'b': out[o++] = '\b'; break;
        case 'f': out[o++] = '\f'; break;
        case 'u': {
            if (i + 4 >= len) break;
            char hex[5] = { s[i+1], s[i+2], s[i+3], s[i+4], 0 };
            unsigned cp = (unsigned)strtoul(hex, NULL, 16);
            i += 4;
            if (cp < 0x80) {
                out[o++] = (char)cp;
            } else if (cp < 0x800) {
                if (o + 2 < cap) {
                    out[o++] = (char)(0xC0 | (cp >> 6));
                    out[o++] = (char)(0x80 | (cp & 0x3F));
                }
            } else {
                if (o + 3 < cap) {
                    out[o++] = (char)(0xE0 | (cp >> 12));
                    out[o++] = (char)(0x80 | ((cp >> 6) & 0x3F));
                    out[o++] = (char)(0x80 | (cp & 0x3F));
                }
            }
            break;
        }
        default: out[o++] = e; break;
        }
    }
    out[o] = 0;
    return o;
}

/*
 * 在 JSON 里找 "key" 的字符串值，写入 out。
 * from/to 限定搜索范围；找到返回 1。
 * 会正确跳过嵌套对象/数组/字符串，不会把更深层同名字段误认为目标。
 */
static int json_find_string(const char *json, int from, int to, const char *key,
                            char *out, int cap)
{
    int klen = (int)strlen(key);
    for (int i = from; i < to - klen - 3; i++) {
        if (json[i] != '"') {
            /* 跳过字符串字面量，避免匹配到值里面的内容 */
            continue;
        }
        /* 读一个字符串 token */
        int j = i + 1, is_escape = 0;
        while (j < to) {
            if (is_escape) is_escape = 0;
            else if (json[j] == '\\') is_escape = 1;
            else if (json[j] == '"') break;
            j++;
        }
        if (j >= to) return 0;
        int slen = j - i - 1;
        if (slen == klen && !strncmp(json + i + 1, key, (size_t)klen)) {
            /* 后面必须是 : */
            int k = j + 1;
            while (k < to && isspace((unsigned char)json[k])) k++;
            if (k < to && json[k] == ':') {
                k++;
                while (k < to && isspace((unsigned char)json[k])) k++;
                if (k < to && json[k] == '"') {
                    int v = k + 1, esc = 0;
                    while (v < to) {
                        if (esc) esc = 0;
                        else if (json[v] == '\\') esc = 1;
                        else if (json[v] == '"') break;
                        v++;
                    }
                    json_unescape(json + k + 1, v - k - 1, out, cap);
                    return 1;
                }
            }
        }
        i = j;   /* 跳过这个字符串 */
    }
    return 0;
}

/*
 * 找 "key" 对应的容器（对象 {...} 或数组 [...]）范围 [*start, *end)，用于限定作用域。
 * 注意数组也要支持：choices 就是数组。
 */
static int json_find_container(const char *json, int from, int to, const char *key,
                               int *start, int *end)
{
    int klen = (int)strlen(key);
    for (int i = from; i < to - klen - 4; i++) {
        if (json[i] != '"') continue;
        int j = i + 1, esc = 0;
        while (j < to) {
            if (esc) esc = 0;
            else if (json[j] == '\\') esc = 1;
            else if (json[j] == '"') break;
            j++;
        }
        if (j >= to) return 0;
        if (j - i - 1 == klen && !strncmp(json + i + 1, key, (size_t)klen)) {
            int k = j + 1;
            while (k < to && isspace((unsigned char)json[k])) k++;
            if (k < to && json[k] == ':') {
                k++;
                while (k < to && isspace((unsigned char)json[k])) k++;
                if (k < to && (json[k] == '{' || json[k] == '[')) {
                    char open = json[k];
                    char close = (open == '{') ? '}' : ']';
                    int depth = 0, m = k, in_str = 0, es = 0;
                    for (; m < to; m++) {
                        char c = json[m];
                        if (in_str) {
                            if (es) es = 0;
                            else if (c == '\\') es = 1;
                            else if (c == '"') in_str = 0;
                            continue;
                        }
                        if (c == '"') in_str = 1;
                        else if (c == open) depth++;
                        else if (c == close) {
                            depth--;
                            if (!depth) { *start = k; *end = m + 1; return 1; }
                        }
                    }
                }
            }
        }
        i = j;
    }
    return 0;
}

/* 从 API 响应里取回复文本；返回 0 成功 */
static int parse_reply(const char *json, char *out, int cap)
{
    int len = (int)strlen(json);

    /* 1) 正常回复：choices[0].message.content */
    int cs, ce;
    if (json_find_container(json, 0, len, "choices", &cs, &ce)) {
        int ms, me;
        if (json_find_container(json, cs, ce, "message", &ms, &me)) {
            if (json_find_string(json, ms, me, "content", out, cap)) {
                if (out[0]) return 0;
                /* content 为空：推理模型把 token 用完了 */
                snprintf(out, cap, "（模型只输出了思考内容，没有给出回答。可调大 max_tokens 或换更简单的问法）");
                return 0;
            }
        }
    }
    /* 2) 错误对象：error.message */
    int es, ee;
    if (json_find_container(json, 0, len, "error", &es, &ee)) {
        char msg[512] = {0};
        if (json_find_string(json, es, ee, "message", msg, sizeof(msg)))
            snprintf(out, cap, "接口返回错误：%s", msg);
        else
            snprintf(out, cap, "接口返回错误（无法解析）");
        return -1;
    }
    if (!len) { snprintf(out, cap, "没有收到任何响应（桥接脚本是否在运行？）"); return -1; }
    snprintf(out, cap, "无法解析接口响应：%.200s", json);
    return -1;
}

/*
 * 字库里只有 ASCII + 常用汉字/符号，模型回复常带 emoji（U+1F300 等）
 * 或变体选择符，这里直接剔除，避免界面上出现莫名的空白。
 */
static void strip_unsupported(char *s)
{
    unsigned char *r = (unsigned char *)s, *w = (unsigned char *)s;
    while (*r) {
        int len = 1;
        unsigned cp = *r;
        if (cp >= 0xF0) { len = 4; cp = ((cp & 0x07) << 18) | ((r[1] & 0x3F) << 12) |
                                            ((r[2] & 0x3F) << 6) | (r[3] & 0x3F); }
        else if (cp >= 0xE0) { len = 3; cp = ((cp & 0x0F) << 12) | ((r[1] & 0x3F) << 6) | (r[2] & 0x3F); }
        else if (cp >= 0xC0) { len = 2; cp = ((cp & 0x1F) << 6) | (r[1] & 0x3F); }
        int drop = 0;
        if (len == 4) drop = 1;                                   /* 增补平面：emoji 等 */
        else if (cp >= 0x2000 && cp <= 0x2BFF) drop = 1;          /* 符号/箭头区间 */
        else if (cp >= 0xFE00 && cp <= 0xFE0F) drop = 1;          /* 变体选择符 */
        else if (cp == 0x3000) { /* 全角空格保留 */ }
        if (!drop) { for (int i = 0; i < len; i++) *w++ = *r++; }
        else r += len;
    }
    *w = 0;
}

/* ---------------- 传输 ---------------- */
/* 构造 popen 用的命令：从 $REQ 文件读请求，把响应写到 stdout */
static void build_command(char *cmd, int cap, const char *reqfile)
{
    if (cfg.transport[0]) {
        /* 自定义模板：$REQ 替换为请求文件路径 */
        const char *p = cfg.transport;
        int o = 0;
        while (*p && o < cap - 1) {
            if (!strncmp(p, "$REQ", 4)) {
                int l = (int)strlen(reqfile);
                if (o + l >= cap - 1) break;
                memcpy(cmd + o, reqfile, l);
                o += l;
                p += 4;
            } else {
                cmd[o++] = *p++;
            }
        }
        cmd[o] = 0;
        return;
    }
    if (!strcmp(cfg.mode, "direct")) {
        /* 板子自己能上外网：直接用 openssl 发 HTTPS（$REQ 里是完整 HTTP 请求） */
        snprintf(cmd, cap, "openssl s_client -quiet -connect %s:443 -servername %s < %s 2>/dev/null",
                 cfg.host, cfg.host, reqfile);
    } else {
        /* 桥接模式：写请求文件，等电脑上的 ai_bridge.sh 把响应写回来 */
        snprintf(cmd, cap,
                 "rm -f %s; cp %s %s; i=0; while [ ! -s %s ] && [ $i -lt 24 ]; do sleep 0.5; i=$((i+1)); done; "
                 "cat %s 2>/dev/null; rm -f %s",
                 cfg.resp_file, reqfile, cfg.req_file, cfg.resp_file, cfg.resp_file, cfg.req_file);
    }
}

/* 把请求写进文件；direct 模式还要写 HTTP 头 */
static int write_request(const char *reqfile, const char *body)
{
    FILE *f = fopen(reqfile, "w");
    if (!f) return -1;
    if (!strcmp(cfg.mode, "direct") && !cfg.transport[0]) {
        fprintf(f, "POST %s HTTP/1.1\r\n", cfg.path);
        fprintf(f, "Host: %s\r\n", cfg.host);
        fprintf(f, "Authorization: Bearer %s\r\n", cfg.key);
        fprintf(f, "Content-Type: application/json\r\n");
        fprintf(f, "Content-Length: %d\r\n", (int)strlen(body));
        fprintf(f, "Connection: close\r\n\r\n");
    }
    fputs(body, f);
    fclose(f);
    return 0;
}

/* 从 HTTP 响应里剥出 body（桥接模式返回的是裸 JSON，direct 模式带响应头） */
static const char *http_body(const char *resp)
{
    if (!strncmp(resp, "HTTP/", 5)) {
        const char *p = strstr(resp, "\r\n\r\n");
        if (p) return p + 4;
        p = strstr(resp, "\n\n");
        if (p) return p + 2;
    }
    return resp;
}

/* 简单处理 chunked 传输（openssl 直连时可能遇到）：把分块拼起来 */
static void dechunk(char *s)
{
    if (strstr(s, "Transfer-Encoding: chunked") == NULL &&
        strstr(s, "transfer-encoding: chunked") == NULL) return;
    char *p = s, *out = s;
    while (*p) {
        char *nl = strchr(p, '\n');
        if (!nl) break;
        long len = strtol(p, NULL, 16);
        if (len <= 0) break;
        p = nl + 1;
        memmove(out, p, (size_t)len);
        out += len;
        p += len;
        while (*p == '\r' || *p == '\n') p++;
    }
    *out = 0;
}

/* ---------------- 线程与状态 ---------------- */
static pthread_mutex_t ai_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_t ai_thread;
static int  ai_thread_live = 0;
static AiState ai_state = AI_IDLE;
static char ai_result[AI_TEXT_MAX * 2];

static void set_result(AiState st, const char *text)
{
    pthread_mutex_lock(&ai_lock);
    snprintf(ai_result, sizeof(ai_result), "%s", text ? text : "");
    ai_state = st;
    pthread_mutex_unlock(&ai_lock);
}

static void *ai_worker(void *arg)
{
    AiMessage *msgs = (AiMessage *)arg;
    int n = 0;
    while (msgs[n].text[0] && n < AI_MAX_TURNS) n++;
    if (n == 0) n = AI_MAX_TURNS;
    /* 传入时用 text[0]==0 作为结束标记，这里重新数一遍 */
    n = 0;
    while (n < AI_MAX_TURNS && msgs[n].text[0]) n++;

    /* 1. 拼请求 JSON */
    int cap = 16384;
    char *body = (char *)malloc(cap);
    if (!body) { set_result(AI_ERROR, "内存不足"); goto out; }
    {
        int o = 0;
        o += snprintf(body + o, cap - o, "{\"model\":\"%s\",\"messages\":[", cfg.model);
        char esc[AI_TEXT_MAX * 2];
        for (int i = 0; i < n && o < cap - 64; i++) {
            json_escape(msgs[i].text, esc, sizeof(esc));
            o += snprintf(body + o, cap - o, "%s{\"role\":\"%s\",\"content\":\"%s\"}",
                          i ? "," : "", msgs[i].mine ? "user" : "assistant", esc);
        }
        snprintf(body + o, cap - o, "],\"max_tokens\":%d", cfg.max_tokens);
        o = (int)strlen(body);
        if (cfg.reasoning_effort[0])
            snprintf(body + o, cap - o, ",\"reasoning_effort\":\"%s\"", cfg.reasoning_effort);
        o = (int)strlen(body);
        snprintf(body + o, cap - o, "}");
    }

    /* 2. 写请求文件 */
    char reqfile[320];
    snprintf(reqfile, sizeof(reqfile), "%s/ai_req_%d.txt", media_tmp_dir(), (int)getpid());
    (void)0;
    if (write_request(reqfile, body) != 0) {
        set_result(AI_ERROR, "无法写入请求文件");
        free(body);
        goto out;
    }

    /* 3. 执行传输命令 */
    char cmd[2048];
    build_command(cmd, sizeof(cmd), reqfile);
    fprintf(stderr, "ai: 执行 %s\n", cmd);
    FILE *fp = popen(cmd, "r");
    if (!fp) {
        set_result(AI_ERROR, "无法启动传输命令");
        unlink(reqfile);
        free(body);
        goto out;
    }
    char *resp = (char *)malloc(32768);
    int rlen = 0;
    if (resp) {
        size_t got;
        while ((got = fread(resp + rlen, 1, 4096, fp)) > 0 && rlen < 32000) rlen += (int)got;
        resp[rlen] = 0;
    }
    int status = pclose(fp);
    unlink(reqfile);
    free(body);

    if (!resp || rlen == 0) {
        char msg[256];
        snprintf(msg, sizeof(msg),
                 "没有收到回复（%s）。%s",
                 status != 0 ? "传输命令失败" : "响应为空",
                 strcmp(cfg.mode, "bridge") == 0 ? "请确认电脑上 ai_bridge.sh 正在运行" : "请检查网络");
        set_result(AI_ERROR, msg);
        free(resp);
        goto out;
    }

    /* 4. 解析 */
    {
        char *b = (char *)http_body(resp);
        dechunk(b);
        char out[AI_TEXT_MAX * 2];
        int r = parse_reply(b, out, sizeof(out));
        strip_unsupported(out);
        set_result(r == 0 ? AI_DONE : AI_ERROR, out);
    }
    free(resp);

out:
    free(msgs);
    pthread_mutex_lock(&ai_lock);
    ai_thread_live = 0;
    pthread_mutex_unlock(&ai_lock);
    return NULL;
}

int ai_send(const AiMessage *msgs, int n)
{
    if (!cfg_ok) return -1;
    if (n <= 0 || n > AI_MAX_TURNS) return -1;

    pthread_mutex_lock(&ai_lock);
    if (ai_state == AI_BUSY) { pthread_mutex_unlock(&ai_lock); return -1; }
    ai_state = AI_BUSY;
    ai_result[0] = 0;
    pthread_mutex_unlock(&ai_lock);

    AiMessage *copy = (AiMessage *)calloc(AI_MAX_TURNS + 1, sizeof(AiMessage));
    if (!copy) { set_result(AI_ERROR, "内存不足"); return -1; }
    for (int i = 0; i < n; i++) copy[i] = msgs[i];

    if (ai_thread_live) pthread_join(ai_thread, NULL);
    if (pthread_create(&ai_thread, NULL, ai_worker, copy) != 0) {
        free(copy);
        set_result(AI_ERROR, "无法创建请求线程");
        return -1;
    }
    ai_thread_live = 1;
    return 0;
}

AiState ai_poll(char *reply, int cap)
{
    AiState st;
    pthread_mutex_lock(&ai_lock);
    st = ai_state;
    if (st == AI_DONE || st == AI_ERROR) {
        if (reply && cap > 0) snprintf(reply, cap, "%s", ai_result);
        ai_state = AI_IDLE;
    }
    pthread_mutex_unlock(&ai_lock);
    return st;
}

void ai_cancel(void)
{
    pthread_mutex_lock(&ai_lock);
    if (ai_state == AI_BUSY) ai_state = AI_IDLE;
    pthread_mutex_unlock(&ai_lock);
}
