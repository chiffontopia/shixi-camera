/*
 * ai.h — AI 聊天后端（对接 OpenAI 兼容接口）
 *
 * 现状：开发板本身没有外网，也不方便在板子上做 TLS，所以默认走"桥接"模式：
 *   板子把请求 JSON 写成本地文件 -> 电脑上的 tools/ai_bridge.sh 取走并调用云端 API
 *   -> 把 API 的 JSON 响应写回板子 -> 板子解析后显示。
 *   配置文件里改 mode=direct 且板子有外网时，则直接用 openssl s_client 发 HTTPS。
 *
 * 请求在独立线程里执行，界面不会被卡住。
 */
#ifndef SHIXI_AI_H
#define SHIXI_AI_H

#define AI_TEXT_MAX 1024
#define AI_MAX_TURNS 12

typedef struct {
    int  mine;                  /* 1 = 用户说的，0 = AI 说的 */
    char text[AI_TEXT_MAX];
} AiMessage;

typedef enum {
    AI_IDLE = 0,   /* 空闲，可以发新请求 */
    AI_BUSY,       /* 请求中 */
    AI_DONE,       /* 有结果可取 */
    AI_ERROR       /* 出错了，错误文案已放在结果里 */
} AiState;

int  ai_init(void);                       /* 读配置，0 = 成功 */
int  ai_configured(void);                 /* 配置是否可用 */
const char *ai_model(void);
const char *ai_mode(void);                /* "bridge" 或 "direct" */
void ai_shutdown(void);

/* 发起一次对话：msgs 是最近若干轮对话（含本轮用户输入），异步执行 */
int  ai_send(const AiMessage *msgs, int n);

/* 取状态；返回 AI_DONE/AI_ERROR 时把文本写入 reply（并自动回到 AI_IDLE） */
AiState ai_poll(char *reply, int cap);
void ai_cancel(void);

#endif /* SHIXI_AI_H */
