/*
 * app_chat.c — AI 聊天（界面演示版）
 *
 * 说明：本应用只实现聊天界面与交互（气泡、输入框、屏幕键盘、发送动画），
 *       回复是本地关键词匹配的预设文案，并没有接入真实大模型。
 *       接入真实模型时只需替换 chat_reply() 里的实现（例如通过 socket/HTTP 请求）。
 */
#include "apps.h"
#include "util.h"
#include "ai.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define TB_H        58
#define INPUT_H     56
#define BUBBLE_PAD  14
#define MAX_MSG     60
#define MAX_LINE    24
#define INPUT_MAX   180
#define CHIP_COUNT  5      /* 快捷提问数量（键盘只能打英文，中文提问靠这些） */

typedef struct {
    int  mine;              /* 1 = 我发的 */
    char text[256];
    int  t_sec;             /* 收到消息时的秒数（用于显示时间） */
} ChatMsg;

static ChatMsg msgs[MAX_MSG];
static int nmsg = 0;
static char draft[INPUT_MAX + 1];
static int  kb_open = 0;
static int  kb_shift = 0;
static int  ai_ready = 0;          /* AI 后端是否可用 */
static int  ai_busy = 0;           /* 正在等待模型回复 */
static int  reply_error = 0;       /* 上一条回复是否是错误 */
static float scroll = 0;           /* 消息列表滚动量（像素） */
static int  dragging = 0;
static int  drag_y0 = 0;
static float drag_scroll0 = 0;
static float content_h = 0;

static int wrap_text(FontId f, const char *text, int max_w, char lines[][256], int max_lines)
{
    int n = 0;
    const char *p = text;
    while (*p && n < max_lines) {
        int w = 0, len = 0;
        int last_space = -1;
        const char *start = p;
        while (*p) {
            /* 取一个 UTF-8 字符 */
            int clen = 1;
            unsigned char c = (unsigned char)*p;
            if (c >= 0xF0) clen = 4;
            else if (c >= 0xE0) clen = 3;
            else if (c >= 0xC0) clen = 2;
            char tmp[8];
            memcpy(tmp, p, clen);
            tmp[clen] = 0;
            int cw = text_width(f, tmp);
            if (*p == '\n') { p++; last_space = -2; break; }
            if (w + cw > max_w && len > 0) break;
            if (*p == ' ') last_space = len;
            w += cw;
            len += clen;
            p += clen;
        }
        if (p == start) break;
        /* ASCII 尽量按空格断行 */
        if (*p && last_space > 0 && (unsigned char)*p < 0x80) {
            int used = last_space;
            memcpy(lines[n], start, used);
            lines[n][used] = 0;
            p = start + used + 1;
        } else {
            memcpy(lines[n], start, len);
            lines[n][len] = 0;
        }
        n++;
        if (*p == 0) break;
    }
    if (n == 0) { lines[0][0] = 0; n = 1; }
    return n;
}

static int bubble_height(const ChatMsg *m, int *out_lines)
{
    static char lines[MAX_LINE][256];
    int maxw = 400;
    int n = wrap_text(FONT_BODY, m->text, maxw, lines, MAX_LINE);
    if (out_lines) *out_lines = n;
    return n * font_height(FONT_BODY) + BUBBLE_PAD * 2;
}

static void add_msg(int mine, const char *text)
{
    if (nmsg >= MAX_MSG) {
        memmove(&msgs[0], &msgs[1], sizeof(ChatMsg) * (MAX_MSG - 1));
        nmsg = MAX_MSG - 1;
    }
    ChatMsg *m = &msgs[nmsg++];
    m->mine = mine;
    snprintf(m->text, sizeof(m->text), "%s", text);
    time_t t = time(NULL);
    struct tm lt;
    localtime_r(&t, &lt);
    m->t_sec = lt.tm_hour * 3600 + lt.tm_min * 60 + lt.tm_sec;
    /* 新消息自动滚到底部 */
    scroll = 1e9f;
}

/* 本地预设回复（关键词匹配，仅当没有配置云端 AI 时使用） */
static const char *local_reply(const char *q)
{
    static int fallback = 0;
    struct {
        const char *key;
        const char *ans;
    } table[] = {
        { "你好", "你好！我是这台开发板的 AI 助手小石。\n现在是演示版，回复来自本地预设文案。" },
        { "hi",   "Hi！有什么可以帮你的吗？（演示版）" },
        { "hello","Hello！很高兴见到你。" },
        { "拍照", "点桌面上的「拍照」就能取景，中间的白色圆键拍照，左下角可以直接进图库。" },
        { "照片", "照片都存在 /root/shixi/photo 目录，图库里可以左右滑动浏览，也能删除。" },
        { "录像", "「录像」里按红色圆键开始录，再按一次停止，会保存成 MJPEG 的 AVI 文件。" },
        { "视频", "录好的视频能在图库里直接播放，也能拷到电脑上用播放器打开。" },
        { "删除", "在图库的查看页，点右上角的垃圾桶图标就能删除，会有二次确认。" },
        { "时间", NULL },
        { "几点", NULL },
        { "名字", "我叫小石，运行在 GEC6818 开发板上，是一只界面演示用的 AI。" },
        { "是谁", "我是小石，这个项目的 AI 聊天界面演示。" },
        { "谢谢", "不客气！随时叫我。" },
        { "再见", "再见，期待下次见面！" },
        { "功能", "这台设备有四个应用：拍照、录像、图库、AI 聊天。都可以直接用触摸屏操作。" },
        { "能做什么", "我能陪聊，也能告诉你设备怎么用。真正的对话能力需要接入云端模型。" },
        { "天气", "我还没联网，查不了天气。（演示版）" },
        { "开发板", "这块是 GEC6818，8 核 Cortex-A53，7 寸 800x480 触摸屏，跑 Linux 3.4。" },
        { "触摸", "屏幕是电容触摸，坐标会自动校准，直接点就行。" },
    };
    for (size_t i = 0; i < sizeof(table) / sizeof(table[0]); i++) {
        if (strstr(q, table[i].key)) {
            if (table[i].ans) return table[i].ans;
            static char tbuf[96];
            time_t t = time(NULL);
            struct tm lt;
            localtime_r(&t, &lt);
            snprintf(tbuf, sizeof(tbuf), "现在是 %02d:%02d:%02d（开发板本地时间）。",
                     lt.tm_hour, lt.tm_min, lt.tm_sec);
            return tbuf;
        }
    }
    static const char *fb[] = {
        "我还在学习中，这个问题暂时答不上来。（演示版，回复是本地预设的）",
        "这个问题有点难，等我接上大模型再回答你吧。",
        "收到！不过我现在只会几句预设台词，试试问「怎么拍照」？",
    };
    return fb[fallback++ % 3];
}

void app_chat_enter(void)
{
    ui_toast_set_bottom(96);
    if (!ai_ready) {
        if (ai_init() == 0) ai_ready = 1;
    }
    if (nmsg == 0) {
        if (ai_ready)
            add_msg(0, "你好！我是接入了云端大模型的 AI 助手。\n有什么想聊的尽管说，也可以问我这台设备怎么用。");
        else
            add_msg(0, "你好！我是 AI 助手。\n（当前未找到 AI 配置 ai.conf，先用本地预设回复和你聊）");
    }
    kb_open = 0;
    draft[0] = 0;
    scroll = 1e9f;
}

void app_chat_leave(void)
{
    kb_open = 0;
}

/* ---------------- 绘制 ---------------- */
static void draw_bubble(Surface *s, const ChatMsg *m, int x, int y, int w, int h)
{
    uint32_t bg = m->mine ? C_ACCENT : C_SURFACE2;
    uint32_t fg = m->mine ? RGB(0x08, 0x2a, 0x20) : C_TEXT;
    gfx_fill_round_rect_a(s, x, y + 2, w, h, 16, C_BLACK, 60);
    gfx_fill_round_rect(s, x, y, w, h, 16, bg);
    /* 小尾巴 */
    if (m->mine) gfx_fill_triangle(s, x + w - 6, y + 14, x + w + 8, y + 20, x + w - 6, y + 26, bg);
    else         gfx_fill_triangle(s, x + 6, y + 14, x - 8, y + 20, x + 6, y + 26, bg);

    static char lines[MAX_LINE][256];
    int n = wrap_text(FONT_BODY, m->text, w - BUBBLE_PAD * 2, lines, MAX_LINE);
    int lh = font_height(FONT_BODY);
    for (int i = 0; i < n; i++)
        text_draw(s, x + BUBBLE_PAD, y + BUBBLE_PAD + i * lh, lines[i], FONT_BODY, fg);
}

static void draw_messages(Surface *s, int top, int bottom)
{
    /* 计算内容总高：与下面绘制时的推进方式保持一致，避免滚到底还留空 */
    int y = 10;
    for (int i = 0; i < nmsg; i++) {
        int lines = 0;
        int h = bubble_height(&msgs[i], &lines) + 18;
        y += h;
    }
    int typing_on = ai_busy ? 1 : 0;
    if (typing_on) y += 62;              /* "正在输入"气泡：44 + 18 */
    content_h = (float)(y + 10);         /* 末尾留 10px 让最新消息完整可见 */

    int view_h = bottom - top;
    float max_scroll = content_h - view_h;
    if (max_scroll < 0) max_scroll = 0;
    if (scroll > max_scroll) scroll = max_scroll;
    if (scroll < 0) scroll = 0;

    gfx_set_clip(0, top, SCREEN_W, view_h);
    int cy = top - (int)scroll + 10;
    int lh = font_height(FONT_BODY);

    for (int i = 0; i < nmsg; i++) {
        static char lines[MAX_LINE][256];
        int nlines = wrap_text(FONT_BODY, msgs[i].text, 400, lines, MAX_LINE);
        int tw = 0;
        for (int k = 0; k < nlines; k++) {
            int w = text_width(FONT_BODY, lines[k]);
            if (w > tw) tw = w;
        }
        int bw = tw + BUBBLE_PAD * 2;
        int bh = nlines * lh + BUBBLE_PAD * 2;
        int bx = msgs[i].mine ? (SCREEN_W - 24 - bw - 10) : 74;
        /* 头像 */
        if (!msgs[i].mine) {
            gfx_fill_circle_a(s, 44, cy + 22, 18, RGB(0x6a, 0x45, 0xd8), 255);
            text_draw_vcenter_center(s, 44, cy + 4, 36, "AI", FONT_SMALL, C_WHITE);
        } else {
            gfx_fill_circle_a(s, SCREEN_W - 44, cy + 22, 18, C_ACCENT_DK, 255);
            icon_draw_cached(s, IC_HOME, SCREEN_W - 44, cy + 22, 18, C_WHITE);
        }
        if (cy + bh > top - 40 && cy < bottom + 40)
            draw_bubble(s, &msgs[i], bx, cy, bw, bh);
        cy += bh + 18;
    }

    /* 正在输入 */
    if (ai_busy) {
        gfx_fill_circle_a(s, 44, cy + 22, 18, RGB(0x6a, 0x45, 0xd8), 255);
        text_draw_vcenter_center(s, 44, cy + 4, 36, "AI", FONT_SMALL, C_WHITE);
        gfx_fill_round_rect(s, 74, cy, 96, 44, 16, C_SURFACE2);
        for (int i = 0; i < 3; i++) {
            int ph = (int)((__builtin_sinf((float)(now_ms() % 900) / 900.0f * 6.283f + i * 1.2f) + 1.0f) * 3);
            gfx_fill_circle_a(s, 98 + i * 22, cy + 22 - ph, 5, C_TEXT, 200);
        }
        cy += 62;
    }
    gfx_reset_clip();
}

static void draw_input_bar(Surface *s, int y)
{
    gfx_fill_rect(s, 0, y, SCREEN_W, SCREEN_H - y, C_BG);
    gfx_fill_rect(s, 0, y, SCREEN_W, 1, C_LINE);
    /* 输入框 */
    gfx_fill_round_rect(s, 16, y + 10, SCREEN_W - 108, INPUT_H - 20, (INPUT_H - 20) / 2, C_SURFACE2);
    if (draft[0]) {
        char show[INPUT_MAX + 8];
        snprintf(show, sizeof(show), "%s", draft);
        /* 太长时只显示尾部 */
        while (text_width(FONT_BODY, show) > SCREEN_W - 140 && show[0]) memmove(show, show + 1, strlen(show));
        text_draw_vcenter(s, 34, y + 10, INPUT_H - 20, show, FONT_BODY, C_TEXT);
    } else {
        text_draw_vcenter(s, 34, y + 10, INPUT_H - 20, kb_open ? "" : "说点什么…（轻触输入）",
                          FONT_BODY, C_TEXT_MUTED);
    }
    /* 发送键 */
    int has = draft[0] != 0;
    gfx_fill_circle(s, SCREEN_W - 48, y + INPUT_H / 2, 24, has ? C_ACCENT : C_SURFACE2);
    icon_draw_cached(s, IC_SEND, SCREEN_W - 48, y + INPUT_H / 2, 22, has ? C_BLACK : C_TEXT_MUTED);
}

/* ---------- 屏幕键盘 ---------- */
#define KEY_W 68
#define KEY_H 44
#define KEY_GAP 6
#define KB_TOP (SCREEN_H - 5 * (KEY_H + KEY_GAP) - 12)

static const char *KB_ROW1 = "1234567890";
static const char *KB_ROW2 = "qwertyuiop";
static const char *KB_ROW3 = "asdfghjkl";
static const char *KB_ROW4 = "zxcvbnm";

static void kb_key_rect(int row, int col, int ncols, int *x, int *y, int *w, int *h)
{
    int total = ncols * KEY_W + (ncols - 1) * KEY_GAP;
    int x0 = (SCREEN_W - total) / 2;
    *x = x0 + col * (KEY_W + KEY_GAP);
    *y = KB_TOP + row * (KEY_H + KEY_GAP);
    *w = KEY_W;
    *h = KEY_H;
}

static void draw_keyboard(Surface *s)
{
    gfx_fill_rect(s, 0, KB_TOP - 12, SCREEN_W, SCREEN_H - KB_TOP + 12, RGB(0x0a, 0x0d, 0x12));
    gfx_fill_rect(s, 0, KB_TOP - 12, SCREEN_W, 1, C_LINE);

    /* 输入预览：键盘弹起时也要能看见正在输入的内容 */
    if (draft[0]) {
        char show[INPUT_MAX + 8];
        snprintf(show, sizeof(show), "%s", draft);
        while (text_width(FONT_BODY, show) > SCREEN_W - 150 && show[0]) memmove(show, show + 1, strlen(show));
        gfx_fill_round_rect(s, 16, KB_TOP - 42, SCREEN_W - 132, 30, 15, C_SURFACE2);
        text_draw_vcenter(s, 30, KB_TOP - 42, 30, show, FONT_BODY, C_TEXT);
        gfx_fill_circle(s, SCREEN_W - 44, KB_TOP - 27, 15, C_ACCENT);
        icon_draw_cached(s, IC_SEND, SCREEN_W - 44, KB_TOP - 27, 15, C_BLACK);
    }

    const char *rows[4] = { KB_ROW1, KB_ROW2, KB_ROW3, KB_ROW4 };
    for (int r = 0; r < 4; r++) {
        int n = (int)strlen(rows[r]);
        for (int c = 0; c < n; c++) {
            int x, y, w, h;
            kb_key_rect(r, c, n, &x, &y, &w, &h);
            char label[2] = { rows[r][c], 0 };
            if (kb_shift) label[0] = (char)(label[0] - 'a' + 'A');
            gfx_fill_round_rect(s, x, y, w, h, 8, C_SURFACE2);
            text_draw_vcenter_center(s, x + w / 2, y, h, label, FONT_BODY, C_TEXT);
        }
    }
    /* 第四行右侧：退格 */
    int x, y, w, h;
    kb_key_rect(3, 7, 8, &x, &y, &w, &h);
    gfx_fill_round_rect(s, x, y, w, h, 8, RGB(0x3a, 0x2a, 0x2e));
    icon_draw_cached(s, IC_BACK, x + w / 2, y + h / 2, 22, RGB(0xff, 0xb0, 0xb8));
    /* 第五行：空格 / 大写 / 收起 / 发送 */
    int y5 = KB_TOP + 4 * (KEY_H + KEY_GAP);
    gfx_fill_round_rect(s, 18, y5, 96, KEY_H, 8, C_SURFACE2);
    text_draw_vcenter_center(s, 18 + 48, y5, KEY_H, kb_shift ? "小写" : "大写", FONT_SMALL, C_TEXT_DIM);
    gfx_fill_round_rect(s, 124, y5, 300, KEY_H, 8, C_SURFACE2);
    text_draw_vcenter_center(s, 124 + 150, y5, KEY_H, "空格", FONT_BODY, C_TEXT);
    gfx_fill_round_rect(s, 434, y5, 96, KEY_H, 8, C_SURFACE2);
    text_draw_vcenter_center(s, 434 + 48, y5, KEY_H, "收起", FONT_BODY, C_TEXT_DIM);
    gfx_fill_round_rect(s, 540, y5, 120, KEY_H, 8, draft[0] ? C_ACCENT : C_SURFACE2);
    text_draw_vcenter_center(s, 540 + 60, y5, KEY_H, "发送", FONT_BODY, draft[0] ? C_BLACK : C_TEXT_MUTED);
    (void)h;
}

/* 本地预设回复（仅在 AI 未配置时兜底） */
static const char *local_reply(const char *q);

static void send_message(void)
{
    if (!draft[0]) return;
    add_msg(1, draft);
    reply_error = 0;
    /* 组织最近若干轮对话作为上下文 */
    if (ai_ready) {
        AiMessage ctx[AI_MAX_TURNS];
        memset(ctx, 0, sizeof(ctx));
        int start = nmsg > AI_MAX_TURNS ? nmsg - AI_MAX_TURNS : 0;
        int k = 0;
        for (int i = start; i < nmsg && k < AI_MAX_TURNS; i++) {
            ctx[k].mine = msgs[i].mine;
            snprintf(ctx[k].text, sizeof(ctx[k].text), "%s", msgs[i].text);
            k++;
        }
        if (ai_send(ctx, k) != 0) {
            reply_error = 1;
            add_msg(0, "上一条还在处理中，请稍等…");
        } else {
            ai_busy = 1;
        }
    } else {
        /* 没有配置 AI：用本地预设，并提示一次 */
        const char *a = local_reply(draft);
        add_msg(0, a);
        ui_toast("未配置 AI（ai.conf），当前为本地预设回复");
    }
    draft[0] = 0;
}

void app_chat_frame(uint64_t t_ms)
{
    Surface *s = gfx_back();
    if (!s) return;
    gfx_reset_clip();
    gfx_fill_rect(s, 0, 0, SCREEN_W, SCREEN_H, C_BG);
    static char subtitle[128];
    if (!ai_ready) {
        snprintf(subtitle, sizeof(subtitle), "未配置模型 · 使用本地预设回复");
    } else {
        const char *m = strrchr(ai_model(), '/');      /* 去掉 deepseek/ 前缀 */
        m = m ? m + 1 : ai_model();
        snprintf(subtitle, sizeof(subtitle), "%s · %s%s", m,
                 strcmp(ai_mode(), "direct") == 0 ? "直连" : "桥接",
                 ai_busy ? " · 思考中…" : " · 在线");
    }
    ui_topbar(s, "AI 助手", subtitle, 1);

    /* 轮询 AI 结果 */
    {
        char reply[2048];
        AiState st = ai_poll(reply, sizeof(reply));
        if (st == AI_DONE) {
            ai_busy = 0;
            add_msg(0, reply);
        } else if (st == AI_ERROR) {
            ai_busy = 0;
            reply_error = 1;
            add_msg(0, reply);
            ui_toast("AI 请求失败");
        }
    }

    int list_top = TB_H;
    int chips_on = (!kb_open && nmsg <= 3);
    /* 宽度不够就少显示几个，避免溢出屏幕 */
    int chip_show = CHIP_COUNT;
    {
        static const char *cw[CHIP_COUNT] = { "你会拍照吗？", "怎么录像？", "现在几点？", "讲个笑话", "你是谁？" };
        int total = 16;
        for (int i = 0; i < CHIP_COUNT; i++) {
            int w = ui_pill_width(cw[i]);
            if (total + w > SCREEN_W - 16) { chip_show = i; break; }
            total += w + 8;
        }
    }
    /* 快捷话题/输入框都要占位置，消息列表不能画到它们下面去 */
    int list_bottom = kb_open ? KB_TOP - 12
                              : SCREEN_H - INPUT_H - (chips_on ? 46 : 0);
    draw_messages(s, list_top, list_bottom);
    if (kb_open) draw_keyboard(s);
    else draw_input_bar(s, SCREEN_H - INPUT_H);

    /* 快捷话题（键盘收起时显示在输入框上方） */
    if (chips_on) {
        static const char *chips[CHIP_COUNT] = { "你会拍照吗？", "怎么录像？", "现在几点？", "讲个笑话", "你是谁？" };
        int x = 16;
        for (int i = 0; i < chip_show; i++) {
            int w = ui_pill_width(chips[i]);
            gfx_fill_round_rect(s, x, SCREEN_H - INPUT_H - 38, w, 30, 15, C_SURFACE);
            text_draw_vcenter_center(s, x + w / 2, SCREEN_H - INPUT_H - 38, 30, chips[i], FONT_SMALL, C_ACCENT);
            x += w + 8;
        }
    }
}

/* 键盘命中测试 */
static int kb_hit(const UiEvent *e)
{
    const char *rows[4] = { KB_ROW1, KB_ROW2, KB_ROW3, KB_ROW4 };
    for (int r = 0; r < 4; r++) {
        int n = (int)strlen(rows[r]);
        int ncols = (r == 3) ? 8 : n;
        for (int c = 0; c < n; c++) {
            int x, y, w, h;
            kb_key_rect(r, c, ncols, &x, &y, &w, &h);
            if (ui_hit(e->x, e->y, x, y, w, h)) {
                char ch = rows[r][c];
                if (kb_shift) ch = (char)(ch - 'a' + 'A');
                int len = (int)strlen(draft);
                if (len < INPUT_MAX) { draft[len] = ch; draft[len + 1] = 0; }
                return 1;
            }
        }
    }
    int x, y, w, h;
    kb_key_rect(3, 7, 8, &x, &y, &w, &h);
    if (ui_hit(e->x, e->y, x, y, w, h)) {
        int len = (int)strlen(draft);
        if (len > 0) draft[len - 1] = 0;
        return 1;
    }
    /* 输入预览条上的发送按钮 */
    if (draft[0] && ui_hit(e->x, e->y, SCREEN_W - 62, KB_TOP - 45, 40, 36)) { send_message(); return 1; }
    int y5 = KB_TOP + 4 * (KEY_H + KEY_GAP);
    if (ui_hit(e->x, e->y, 18, y5, 96, KEY_H)) { kb_shift = !kb_shift; return 1; }
    if (ui_hit(e->x, e->y, 124, y5, 300, KEY_H)) {
        int len = (int)strlen(draft);
        if (len < INPUT_MAX) { draft[len] = ' '; draft[len + 1] = 0; }
        return 1;
    }
    if (ui_hit(e->x, e->y, 434, y5, 96, KEY_H)) { kb_open = 0; return 1; }
    if (ui_hit(e->x, e->y, 540, y5, 120, KEY_H)) { send_message(); return 1; }
    return 0;
}

int app_chat_event(const UiEvent *e)
{
    if (kb_open) {
        if (e->type == UI_EV_UP) {
            if (e->tap) {
                if (ui_topbar_back_hit(e->x, e->y)) { kb_open = 0; return 0; }
                if (e->y < KB_TOP - 12) return 0;
                kb_hit(e);
                return 0;
            }
        }
        if (e->type == UI_EV_DOWN && e->y < KB_TOP - 12) {
            dragging = 1;
            drag_y0 = e->y;
            drag_scroll0 = scroll;
        }
        if (e->type == UI_EV_MOVE && dragging) {
            scroll = drag_scroll0 - (e->y - drag_y0);
            if (scroll < 0) scroll = 0;
        }
        if (e->type == UI_EV_UP) dragging = 0;
        return 0;
    }

    if (e->type == UI_EV_DOWN) {
        if (e->y < SCREEN_H - INPUT_H) {
            dragging = 1;
            drag_y0 = e->y;
            drag_scroll0 = scroll;
        }
        return 0;
    }
    if (e->type == UI_EV_MOVE && dragging) {
        scroll = drag_scroll0 - (e->y - drag_y0);
        if (scroll < 0) scroll = 0;
        return 0;
    }
    if (e->type == UI_EV_UP) {
        dragging = 0;
        if (!e->tap) return 0;
        if (ui_topbar_back_hit(e->x, e->y)) return 1;

        /* 输入框 -> 打开键盘 */
        if (e->y >= SCREEN_H - INPUT_H) {
            if (ui_hit(e->x, e->y, 16, SCREEN_H - INPUT_H + 10, SCREEN_W - 108, INPUT_H - 20)) {
                kb_open = 1;
                return 0;
            }
            if (ui_hit(e->x, e->y, SCREEN_W - 76, SCREEN_H - INPUT_H + 4, 56, 48)) {
                send_message();
                return 0;
            }
            return 0;
        }
        /*
         * 快捷话题。注意别再加 !was_drag 判断：
         * 每次触摸都会先来一个 DOWN（把 dragging 置 1），加了就会永远点不动；
         * 拖动的情况 e->tap 已经是 0，这里用 tap 判断即可。
         */
        if (nmsg <= 3 && e->y >= SCREEN_H - INPUT_H - 40 && e->y < SCREEN_H - INPUT_H - 4) {
            static const char *chips[CHIP_COUNT] = { "你会拍照吗？", "怎么录像？", "现在几点？", "讲个笑话", "你是谁？" };
            int x = 16;
            for (int i = 0; i < 3; i++) {
                int w = ui_pill_width(chips[i]);
                if (ui_hit(e->x, e->y, x, SCREEN_H - INPUT_H - 38, w, 30)) {
                    snprintf(draft, sizeof(draft), "%s", chips[i]);
                    send_message();
                    return 0;
                }
                x += w + 8;
            }
        }
        return 0;
    }
    return 0;
}

const AppDef g_app_chat = {
    .title = "AI聊天",
    .en = "AI Chat",
    .icon = APPICON_CHAT,
    .needs_camera = 0,
    .enter = app_chat_enter,
    .leave = app_chat_leave,
    .frame = app_chat_frame,
    .event = app_chat_event
};
