/*
 * aitest.c — 板端 AI 接口自检工具（不开界面就能验证整条链路）
 *
 * 用法: ./aitest [问题]
 *   ./aitest                     用默认问题
 *   ./aitest "你好，介绍一下你自己"
 */
#include "ai.h"
#include "media.h"
#include "util.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    const char *q = argc > 1 ? argv[1] : "用一句话介绍你自己";
    if (media_init() != 0) { printf("存储初始化失败\n"); return 1; }
    if (ai_init() != 0) {
        printf("AI 未配置（检查 %s/ai.conf）\n", media_root());
        return 1;
    }
    printf("模式=%s 模型=%s\n", ai_mode(), ai_model());
    printf("提问：%s\n", q);

    AiMessage msgs[AI_MAX_TURNS];
    memset(msgs, 0, sizeof(msgs));
    msgs[0].mine = 1;
    snprintf(msgs[0].text, sizeof(msgs[0].text), "%s", q);
    if (ai_send(msgs, 1) != 0) { printf("发送失败\n"); return 1; }

    uint64_t t0 = now_ms();
    char reply[2048];
    for (;;) {
        AiState st = ai_poll(reply, sizeof(reply));
        if (st == AI_DONE) { printf("\n回答（%.1f 秒）：\n%s\n", (now_ms()-t0)/1000.0, reply); return 0; }
        if (st == AI_ERROR) { printf("\n出错（%.1f 秒）：\n%s\n", (now_ms()-t0)/1000.0, reply); return 2; }
        if (now_ms() - t0 > 75000) { printf("\n超时\n"); return 3; }
        usleep(200000);
        printf(".");
        fflush(stdout);
    }
}
