#!/bin/sh
# ============================================================
#  ai_bridge.sh — 在电脑上运行，把开发板的 AI 请求转发到云端 API
#
#  为什么需要它：开发板没有外网，也不方便在板上做 TLS；但电脑能 SSH 到板子，
#  所以由电脑轮询板子上的请求文件、调用 HTTPS API、再把结果写回板子。
#
#  用法（在电脑上开一个终端挂着）：
#      ./tools/ai_bridge.sh
#  可选环境变量：
#      BOARD=root@169.254.193.77   PW=123456   BOARD_DIR=/root/shixi
#      API_URL / API_KEY / API_MODEL  （默认取 src/ai.conf 里的值）
# ============================================================
set -u

BOARD="${BOARD:-root@169.254.193.77}"
PW="${PW:-123456}"
BOARD_DIR="${BOARD_DIR:-/root/shixi}"
# 配置文件可能放在 tools/ 或 src/ 下
if [ -z "${CONF:-}" ]; then
    if [ -f "$(dirname "$0")/ai.conf" ]; then CONF="$(dirname "$0")/ai.conf"
    elif [ -f "$(dirname "$0")/../ai.conf" ]; then CONF="$(dirname "$0")/../ai.conf"
    else CONF="$(dirname "$0")/ai.conf"; fi
fi

REQ="$BOARD_DIR/tmp/ai_req.json"
RESP="$BOARD_DIR/tmp/ai_resp.txt"

SSH="sshpass -p $PW ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=8 $BOARD"

# 读取配置（缺省用题目给的端点）
API_URL="${API_URL:-https://api.commandcode.ai/provider/v1/chat/completions}"
API_KEY="${API_KEY:-}"
API_MODEL="${API_MODEL:-deepseek/deepseek-v4.1-flash}"
if [ -f "$CONF" ]; then
    HOST=$(sed -n 's/^api_host=//p' "$CONF" | head -1)
    PATHV=$(sed -n 's/^api_path=//p' "$CONF" | head -1)
    K=$(sed -n 's/^api_key=//p' "$CONF" | head -1)
    M=$(sed -n 's/^api_model=//p' "$CONF" | head -1)
    [ -n "${HOST:-}" ] && [ -n "${PATHV:-}" ] && API_URL="https://$HOST$PATHV"
    [ -n "${K:-}" ] && API_KEY="$K"
    [ -n "${M:-}" ] && API_MODEL="$M"
fi
if [ -z "$API_KEY" ]; then
    echo "错误：没有 API key。请在 $CONF 里填 api_key=，或用 API_KEY=... 传入" >&2
    exit 1
fi

echo "AI 桥接已启动"
echo "  开发板: $BOARD"
echo "  接口:   $API_URL"
echo "  模型:   $API_MODEL"
echo "  板端请求文件: $REQ"
echo "保持这个终端开着；板子上发消息就会自动转发。Ctrl+C 退出。"
echo

COUNT=0
while true; do
    # 一次 SSH 取走请求（原子 mv，避免重复处理）
    BODY=$($SSH "if [ -s $REQ ]; then mv $REQ $REQ.proc 2>/dev/null && cat $REQ.proc; fi" 2>/dev/null)
    if [ -n "${BODY:-}" ]; then
        COUNT=$((COUNT+1))
        echo "[$COUNT] 收到请求，长度 ${#BODY} 字节：$(printf '%s' "$BODY" | head -c 200)"
        echo "    正在调用模型…"
        START=$(date +%s)
        JSON=$(printf '%s' "$BODY" | curl -s -m 120 -X POST "$API_URL" \
                 -H "Authorization: Bearer $API_KEY" \
                 -H "Content-Type: application/json" \
                 --data-binary @- 2>/dev/null)
        END=$(date +%s)
        if [ -z "$JSON" ]; then
            JSON='{"error":{"message":"curl 请求失败（电脑网络不通？）"}}'
        fi
        # 写回板子（先写临时文件再 mv，板子那边看到的是完整文件）
        printf '%s' "$JSON" | $SSH "cat > $RESP.tmp && mv $RESP.tmp $RESP; rm -f $REQ.proc" 2>/dev/null
        # 顺便打印模型回答，方便在电脑上看
        ANSWER=$(printf '%s' "$JSON" | sed -n 's/.*"content":"\([^"]*\)".*/\1/p' | head -c 120)
        echo "    完成（$((END-START)) 秒）：${ANSWER:-（无 content 或出错）}"
    fi
    sleep 0.5
done
