#!/bin/sh
# ============================================================
#  run_board.sh — 一键推送到开发板并运行
#
#  用法:
#    ./run_board.sh            编译 + 推送 + 启动（后台运行，开调试通道）
#    ./run_board.sh stop       停止开发板上的程序
#    ./run_board.sh logs       查看运行日志
#    ./run_board.sh shot       截屏并转成 PNG（需要本机有 python3+PIL）
#    ./run_board.sh tap X Y    模拟点击（需要程序以调试模式启动）
#
#  环境变量: BOARD=root@IP  BOARD_DIR=/root/shixi
# ============================================================
set -e
BOARD="${BOARD:-root@169.254.193.77}"
BOARD_DIR="${BOARD_DIR:-/root/shixi}"
PW="${PW:-123456}"
SSH="sshpass -p $PW ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $BOARD"
SCP="sshpass -p $PW scp -O -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
HERE="$(cd "$(dirname "$0")" && pwd)"

case "${1:-start}" in
stop)
    $SSH 'P=$(pidof shixi); [ -n "$P" ] && kill $P; true; rm -f /tmp/shixi.lock; echo 已停止' 
    ;;
logs)
    $SSH "tail -30 /tmp/shixi.log"
    ;;
shot)
    NAME="${2:-/tmp/board_shot}"
    $SSH "/tmp/fbshot $NAME.raw >/dev/null && echo 已抓取 $NAME.raw"
    $SCP "$BOARD:$NAME.raw" "$NAME.raw" >/dev/null
    if command -v python3 >/dev/null 2>&1; then
        python3 "$HERE/tools/fb2png.py" "$NAME.raw"
    fi
    ;;
tap)
    $SSH "echo 'tap $2 $3' > /tmp/shixi_ctrl; echo 已注入 tap $2 $3"
    ;;
start)
    echo "==> 编译"
    make -C "$HERE"
    echo "==> 停掉板子上正在运行的程序"
    # 用 -x 精确匹配进程名：用 -f 匹配路径会连自己这条 ssh 会话一起杀掉
    $SSH "P=\$(pidof shixi); [ -n \"\$P\" ] && kill \$P; true; rm -f /tmp/shixi.lock; mkdir -p $BOARD_DIR" >/dev/null
    sleep 1
    echo "==> 上传到 $BOARD:$BOARD_DIR"
    $SCP "$HERE/bin/shixi" "$BOARD:$BOARD_DIR/" >/dev/null
    # AI 配置（存在就一起传，且不覆盖板子上已有的）
    if [ -f "$HERE/ai.conf" ]; then
        $SSH "test -f $BOARD_DIR/ai.conf" 2>/dev/null || $SCP "$HERE/ai.conf" "$BOARD:$BOARD_DIR/" >/dev/null
        echo "    (ai.conf 已就位)"
    fi
    echo "==> 启动（后台，带调试输入通道）"
    $SSH "cd $BOARD_DIR && chmod +x shixi && SHIXI_DEBUG_INPUT=1 setsid nohup ./shixi > /tmp/shixi.log 2>&1 < /dev/null & sleep 2; cat /tmp/shixi.log"
    echo "==> 完成。日志: ./run_board.sh logs   截屏: ./run_board.sh shot   模拟点击: ./run_board.sh tap 400 430"
    ;;
*)
    echo "用法: $0 [start|stop|logs|shot|tap X Y]"
    ;;
esac
